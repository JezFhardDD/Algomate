extends Control

@onready var array: TextureButton = $contents/array
@onready var linked_list: TextureButton = $contents/linked_list
@onready var stack: TextureButton = $contents/stack
@onready var queue: TextureButton = $contents/queue
@onready var tree: TextureButton = $contents/tree
@onready var binary_tree: TextureButton = $"contents/binary tree"
@onready var binary_search_tree: TextureButton = $"contents/binary search tree"
@onready var graph: TextureButton = $contents/graph

@export var press_scale := Vector2(0.9, 0.9)
@export var normal_scale := Vector2(1, 1)
@export var bounce_time := 0.2



func play_button_bounce(button: Control) -> void:
	if button == null:
		return

	var tween := create_tween()
	tween.set_trans(Tween.TRANS_BACK)
	tween.set_ease(Tween.EASE_OUT)

	tween.tween_property(button, "scale", press_scale, bounce_time / 2)
	tween.tween_property(button, "scale", normal_scale, bounce_time / 2)

	await tween.finished


func _on_array_pressed() -> void:
	await play_button_bounce(array)

func _on_linked_list_pressed() -> void:
	await play_button_bounce(linked_list)

func _on_stack_pressed() -> void:
	await play_button_bounce(stack)

func _on_queue_pressed() -> void:
	await play_button_bounce(queue)

func _on_tree_pressed() -> void:
	await play_button_bounce(tree)

func _on_binary_tree_pressed() -> void:
	await play_button_bounce(binary_tree)

func _on_binary_search_tree_pressed() -> void:
	await play_button_bounce(binary_search_tree)

func _on_graph_pressed() -> void:
	await play_button_bounce(graph)

func _on_back_button_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/homepage.tscn")
